import turtle
import math

screen = turtle.Screen()
screen.bgcolor("black")
screen.title("name ❤️")

t = turtle.Turtle()
t.hideturtle()

def heart(scale, color, draw_speed):
    t.speed(draw_speed)
    t.penup()
    
    # Считаем стартовую точку (i=0)
    x = scale * 16 * math.sin(0)**3
    y = scale * (13 * math.cos(0) - 5 * math.cos(0) - 2 * math.cos(0) - math.cos(0))
    
    t.goto(x, y)
    t.pendown()
    t.color(color)
    t.begin_fill()
    
    for i in range(1, 361, 2):
        angle = math.radians(i)
        x = scale * 16 * math.sin(angle)**3
        y = scale * (
            13 * math.cos(angle)
            - 5 * math.cos(2 * angle)
            - 2 * math.cos(3 * angle)
            - math.cos(4 * angle)
        )
        t.goto(x, y)
    
    t.end_fill()
    t.penup()

# 1. Быстро рисуем тень
heart(16, "#330000", 0) 

# 2. Постепенно рисуем основное сердце
heart(13, "#ff1a1a", 5) # 5 — спокойная, плавная скорость

# 3. Пишем новое пожелание
t.goto(0, -220) # Немного опустил, чтобы текст был под сердцем
t.color("#ff4d6d")
t.write(
    "text! ❤️",
    align="center",
    font=("Segoe UI", 20, "bold")
)

turtle.done()